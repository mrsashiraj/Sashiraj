# Sashiraj Subedi — Portfolio

**Live:** [www.sashiraj.com.np](https://www.sashiraj.com.np)

Personal portfolio site for Sashiraj Subedi — Systems Architect & Venture Growth. Built with React + Vite, styled with Tailwind CSS, deployed to Cloudflare Pages via GitHub Actions.

---

## Repository Structure

```
sashiraj-portfolio/
├── public/
│   ├── _redirects          # SPA routing rule for Cloudflare Pages
│   └── _headers            # Security + cache headers
├── src/
│   ├── components/
│   │   ├── Hero/           # Hero landing section
│   │   ├── Skills/         # Competency switcher (Managerial / Technical)
│   │   ├── Projects/       # Project Intelligence grid
│   │   ├── Ventures/       # Active Ventures grid
│   │   ├── Timeline/       # Professional History timeline
│   │   ├── Academics/      # Academic Architecture
│   │   ├── Research/       # Research Repository
│   │   ├── Contact/        # Establish Uplink contact form
│   │   └── shared/         # Navbar, Modal, CardGrid, WhatsAppFloat
│   ├── data/
│   │   └── portfolioData.js  # ← ALL content lives here. Edit this to update the site.
│   ├── hooks/
│   │   ├── useTheme.js     # Dark/light toggle with localStorage
│   │   ├── useReveal.js    # IntersectionObserver scroll animations
│   │   ├── useClock.js     # Live Kathmandu time
│   │   └── useModal.js     # Modal open/close/carousel state
│   ├── styles/
│   │   └── global.css      # CSS variables, Tailwind base, utility classes
│   ├── App.jsx             # Root component — assembles all sections
│   └── main.jsx            # React entry point
├── .github/
│   └── workflows/
│       └── deploy.yml      # CI/CD: build → Cloudflare Pages on push to main
├── index.html
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── package.json
```

---

## Getting Started

### Prerequisites
- Node.js 18+
- npm 9+

### Local Development

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/sashiraj-portfolio.git
cd sashiraj-portfolio

# 2. Install dependencies
npm install

# 3. Start dev server
npm run dev
# → http://localhost:5173
```

### Production Build

```bash
npm run build
# Output in /dist — ready to deploy
```

---

## Updating Content

**All site content is in one file:** `src/data/portfolioData.js`

| Export | Section | What to edit |
|--------|---------|-------------|
| `META` | Nav, Hero, Contact | Name, tagline, bio, phone |
| `PROJECTS` | Project Intelligence | Add/remove/edit projects |
| `VENTURES` | Active Ventures | Add/remove/edit ventures |
| `TIMELINE` | Professional History | Work experience entries |
| `ACADEMICS` | Academic Architecture | Degrees |
| `PAPERS` | Research Repository | Publications |
| `SKILLS` | Competency | Skill categories and items |

---

## Deployment — Cloudflare Pages

This repo deploys automatically to Cloudflare Pages via GitHub Actions.

### One-time Setup

1. **Create a Cloudflare Pages project** named `sashiraj-portfolio` in your Cloudflare dashboard.

2. **Add a custom domain** `www.sashiraj.com.np` in Pages → Custom domains.

3. **Add two GitHub repository secrets** (Settings → Secrets → Actions):

   | Secret | Where to find it |
   |--------|-----------------|
   | `CF_API_TOKEN` | Cloudflare → Profile → API Tokens → Create Token (use *Edit Cloudflare Pages* template) |
   | `CF_ACCOUNT_ID` | Cloudflare → Overview → right sidebar |

4. **Push to `main`** — the workflow triggers automatically.

### Manual Deploy (one-off)

```bash
npm run build
npx wrangler pages deploy dist --project-name=sashiraj-portfolio
```

---

## Contact Form

The contact form uses a `mailto:` link by default — no backend required.

To switch to a proper form endpoint, edit `src/components/Contact/Contact.jsx` and replace the `handleTransmit` function with your preferred service:

- **[Formspree](https://formspree.io)** — free tier, no backend
- **[EmailJS](https://www.emailjs.com)** — send via Gmail/Outlook from the browser
- **Cloudflare Workers** — serverless function in the same Cloudflare account

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 |
| Build tool | Vite 5 |
| Styling | Tailwind CSS 3 |
| Fonts | Cormorant Garamond + Inter (Google Fonts) |
| Deployment | Cloudflare Pages |
| CI/CD | GitHub Actions |

---

## License

All rights reserved — Sashiraj Subedi.
