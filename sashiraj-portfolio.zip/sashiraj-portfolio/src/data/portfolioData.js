// ─────────────────────────────────────────────
//  src/data/portfolioData.js
//  Single source of truth for all portfolio content.
//  Edit this file to update any section of the site.
// ─────────────────────────────────────────────

export const META = {
  name: 'Sashiraj Subedi',
  tagline: 'Strategy & Operations',
  dossierVersion: 'Core Dossier v9.8',
  location: 'Kathmandu, Nepal',
  phone: '+977 9841000000',
  whatsapp: 'https://wa.me/9779841000000',
  heroLine1: 'Systems',
  heroItalic1: 'Architect',
  heroLine2: 'Venture',
  heroItalic2: 'Growth.',
  heroBio:
    'Sashiraj Subedi orchestrates operational logic for complex ventures. Bridging statistical integrity with rapid industrial scaling across Himalayan markets.',
}

export const PROJECTS = [
  {
    id: 'sahayatri',
    tag: 'Logistics Architecture',
    title: 'Sahayatri',
    info: 'Designing a community-driven logistics node specifically for Himalayan terrain challenges, focusing on last-mile delivery and localized resource distribution.',
    specs: 'Node.js event loops, Real-time telemetry, PostGIS geospatial indexing.',
    status: 'Version 2.4 — Optimization Phase.',
  },
  {
    id: 'paisa',
    tag: 'Fintech Logic',
    title: 'Paisa',
    info: 'A high-integrity transaction monitoring dashboard designed to provide transparency in regional trade and local cooperative financing cycles.',
    specs: 'Statistical regression for anomaly detection, React-driven visualization, Multi-ledger mapping.',
    status: 'Closed Beta Build.',
  },
  {
    id: 'fsms',
    tag: 'Industrial QA',
    title: 'FSMS Gov',
    info: 'Digitized the Food Safety Management System (ISO 22000) for Sujal Dairy, moving from manual logs to a real-time automated audit environment.',
    specs: 'Quality assurance automation, HACCP monitoring, Cloud-native secure logging.',
    status: 'Deployed — Sujal Dairy (Laxmi Group).',
  },
  {
    id: 'census',
    tag: 'Federal Data Ops',
    title: 'Natl Census',
    info: 'Oversaw field operations and data integrity during the 2021 Nepal National Census for the Central Bureau of Statistics.',
    specs: 'Large-scale field enumeration, Systematic validation protocols, SPSS data cleansing.',
    status: 'Archived — Complete.',
  },
]

export const VENTURES = [
  {
    id: 'munal',
    tag: 'Automotive R&D',
    title: 'Munal',
    info: 'Engineering specialized terrain-utility systems for light commercial vehicles in Nepal, focusing on suspension and drivetrain longevity.',
    specs: 'High-stress metallurgy testing, Component prototyping, Regional supply network.',
    status: '@munal_np (Instagram)',
  },
  {
    id: 'damai',
    tag: 'Heritage Logistics',
    title: 'Damai',
    info: 'Modernizing the heritage apparel market by integrating industrial JIT (Just-in-Time) manufacturing with high-end artisan craft.',
    specs: 'Zero-waste logistics, Global dispatch logic, Artisan partnership protocols.',
    status: '@damai_np (Instagram)',
  },
  {
    id: 'sarky',
    tag: 'Tactical Gear',
    title: 'Sarky',
    info: 'Developing tactical footwear for professional utility, engineered to withstand the unique acidity and moisture profiles of Himalayan soil.',
    specs: 'Ergonomic stress-mapping, Material science R&D, Durability benchmarking.',
    status: '@sarky_np (Instagram)',
  },
]

export const TIMELINE = [
  {
    id: 'laxmi',
    period: '2021 — PRESENT',
    title: 'Strategy & Distribution Node',
    description:
      'Leading Sujal Dairy distribution logistics and digital transformation protocols for Sujal Food (Laxmi Group).',
    active: true,
  },
  {
    id: 'cbs',
    period: '2021 — 2022',
    title: 'Field Data Oversight',
    description:
      'National Census Enumeration Lead for CBS Nepal. Managed regional data integrity and human capital deployment.',
    active: false,
  },
]

export const ACADEMICS = [
  {
    id: 'msc',
    level: 'Post-Graduate',
    degree: 'M.Sc. Strategic Intelligence',
    description:
      'Modeling competitive vulnerabilities and high-integrity decision frameworks for industrial growth nodes.',
  },
  {
    id: 'bsc',
    level: 'Under-Graduate',
    degree: 'B.Sc. Statistics',
    description:
      'Focus on probabilistic modeling and systematic error propagation analysis in large-scale datasets.',
  },
]

export const PAPERS = [
  {
    id: 'urban',
    tag: 'Quant-Ref: 24/A',
    title: 'Urban Consumption',
    info: 'A comprehensive statistical study on the shifting luxury consumption patterns of middle-income households in the Kathmandu Basin.',
    specs: 'Sample size n=500, Multi-variable regression modeling, SPSS data analysis.',
    status: 'Published Research.',
  },
  {
    id: 'data',
    tag: 'Stats-Ref: 22/C',
    title: 'Data Integrity',
    info: 'Exploration of error propagation in manual field data collection versus tablet-based enumeration in large-scale national surveys.',
    specs: 'Probability distributions, Human-error mitigation mapping.',
    status: 'Academic Paper.',
  },
]

export const SKILLS = {
  managerial: [
    {
      cat: 'Operations',
      items: ['Venture Scaling', 'Supply Chain Logic', 'JIT Manufacturing', 'Project Arch'],
    },
    {
      cat: 'Compliance',
      items: ['ISO 22000 Governance', 'HACCP Protocols', 'Quality Assurance', 'Market Entry'],
    },
    {
      cat: 'Leadership',
      items: ['Crisis Management', 'Stakeholder Logic', 'Resource Deployment', 'Strategy Nodes'],
    },
  ],
  technical: [
    {
      cat: 'Data Science',
      items: ['Python Modeling', 'SQL Architecture', 'SPSS Statistics', 'Regression'],
    },
    {
      cat: 'Analysis',
      items: ['Field Survey Logic', 'Systematic Validation', 'ETL Pipeline Design', 'Data Cleaning'],
    },
    {
      cat: 'Systems',
      items: ['API Integration', 'Data Visualization', 'Workflow Automation', 'UI Architecture'],
    },
  ],
}
