// src/components/Timeline/Timeline.jsx
import { TIMELINE } from '../../data/portfolioData'

export default function Timeline() {
  return (
    <section className="py-24 px-6 lg:px-20">
      <div className="max-w-4xl">
        <h2 className="font-serif text-5xl italic mb-16 reveal">Professional History</h2>
        <div className="space-y-16 border-l border-main pl-8 ml-2">
          {TIMELINE.map((item) => (
            <div key={item.id} className="relative reveal">
              <div
                className={`absolute -left-[37px] top-0 w-4 h-4 rounded-full ${
                  item.active ? 'bg-brand-gold' : 'bg-brand-gold/30'
                }`}
              />
              <span className="text-brand-gold text-[9px] uppercase tracking-widest block mb-1">
                {item.period}
              </span>
              <h3 className="text-2xl font-serif italic mb-2">{item.title}</h3>
              <p className="text-dim text-[14px] font-light">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
