// src/components/Academics/Academics.jsx
import { ACADEMICS } from '../../data/portfolioData'

export default function Academics() {
  return (
    <section className="py-20 px-6 lg:px-20 bg-[var(--surface)] border-y border-main">
      <h2 className="font-serif text-5xl italic mb-12 reveal">Academic Architecture</h2>
      <div className="grid md:grid-cols-2 gap-12">
        {ACADEMICS.map((item) => (
          <div key={item.id} className="reveal">
            <h3 className="text-brand-gold text-[10px] uppercase tracking-widest mb-4 font-bold">
              {item.level}
            </h3>
            <h4 className="font-serif text-3xl mb-4 italic">{item.degree}</h4>
            <p className="text-dim text-[14px] font-light leading-relaxed">{item.description}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
