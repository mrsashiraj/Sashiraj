// src/components/Skills/Skills.jsx
import { useState, useEffect, useRef } from 'react'
import { SKILLS } from '../../data/portfolioData'

export default function Skills() {
  const [active, setActive] = useState('managerial')
  const barRef = useRef(null)

  const resetBar = () => {
    const bar = barRef.current
    if (!bar) return
    bar.style.transition = 'none'
    bar.style.width = '0%'
    setTimeout(() => {
      bar.style.transition = 'width 10s linear'
      bar.style.width = '100%'
    }, 50)
  }

  const switchSkill = (type) => {
    setActive(type)
    resetBar()
  }

  useEffect(() => { resetBar() }, [])

  const btnClass = (type) =>
    active === type
      ? 'text-left px-6 py-4 text-[10px] uppercase tracking-widest bg-brand-gold text-black font-bold transition-all'
      : 'text-left px-6 py-4 text-[10px] uppercase tracking-widest text-dim border border-main transition-all'

  return (
    <section className="py-16 px-6 lg:px-20 bg-[var(--surface)] border-y border-main">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-16">
        {/* Sidebar */}
        <div className="md:w-1/4">
          <h2 className="font-serif text-4xl italic mb-8">Competency</h2>
          <div className="flex flex-col gap-3">
            <button className={btnClass('managerial')} onClick={() => switchSkill('managerial')}>
              Managerial Core
            </button>
            <button className={btnClass('technical')} onClick={() => switchSkill('technical')}>
              Technical Stack
            </button>
          </div>
        </div>

        {/* Grid */}
        <div className="md:w-3/4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10">
            {SKILLS[active].map((group) => (
              <div key={group.cat} className="space-y-4">
                <p className="text-[9px] uppercase text-brand-gold tracking-widest font-bold">
                  {group.cat}
                </p>
                <div className="space-y-2">
                  {group.items.map((item) => (
                    <p key={item} className="text-dim text-[14px] font-light">
                      {item}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-12 w-full bg-black/5 dark:bg-white/5">
            <div ref={barRef} className="progress-bar" />
          </div>
        </div>
      </div>
    </section>
  )
}
