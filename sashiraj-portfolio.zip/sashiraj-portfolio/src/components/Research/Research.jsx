// src/components/Research/Research.jsx
import { PAPERS } from '../../data/portfolioData'
import CardGrid from '../shared/CardGrid'

export default function Research({ onOpen }) {
  return (
    <section className="py-20 px-6 lg:px-20">
      <h2 className="font-serif text-5xl italic mb-12 reveal">Research Repository</h2>
      <div className="grid lg:grid-cols-2 gap-8">
        <CardGrid items={PAPERS} onOpen={onOpen} category="papers" />
      </div>
    </section>
  )
}
