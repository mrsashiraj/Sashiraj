// src/components/Ventures/Ventures.jsx
import { VENTURES } from '../../data/portfolioData'
import CardGrid from '../shared/CardGrid'

export default function Ventures({ onOpen }) {
  return (
    <section className="py-20 px-6 lg:px-20 bg-[var(--surface)] border-y border-main">
      <h2 className="font-serif text-5xl italic mb-12 reveal">Active Ventures</h2>
      <div className="grid md:grid-cols-3 gap-6">
        <CardGrid items={VENTURES} onOpen={onOpen} category="ventures" />
      </div>
    </section>
  )
}
