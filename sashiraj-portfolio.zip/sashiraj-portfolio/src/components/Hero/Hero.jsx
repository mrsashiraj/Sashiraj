// src/components/Hero/Hero.jsx
import { META } from '../../data/portfolioData'

export default function Hero() {
  return (
    <section className="min-h-[80vh] flex items-center px-6 lg:px-20 pt-32 pb-16">
      <div className="max-w-6xl">
        <h2 className="text-brand-gold text-[9px] uppercase tracking-[0.8em] mb-4 reveal active">
          {META.dossierVersion}
        </h2>
        <h1
          className="font-serif text-6xl lg:text-[10rem] leading-[0.82] mb-8 reveal active"
          style={{ transitionDelay: '100ms' }}
        >
          {META.heroLine1}{' '}
          <span className="italic font-normal">{META.heroItalic1}</span> &{' '}
          <br />
          <span className="italic font-normal text-brand-gold">{META.heroLine2}</span>{' '}
          {META.heroItalic2}
        </h1>
        <p
          className="text-dim max-w-xl leading-relaxed text-[15px] font-light reveal active"
          style={{ transitionDelay: '200ms' }}
        >
          {META.heroBio}
        </p>
      </div>
    </section>
  )
}
