// src/components/Contact/Contact.jsx
import { useState } from 'react'
import { META } from '../../data/portfolioData'

const STATUS = {
  idle: 'Transmit',
  sending: 'Encrypting...',
  sent: 'Transmitted ✓',
  error: 'TX Error — Retry',
}

export default function Contact() {
  const [name, setName] = useState('')
  const [message, setMessage] = useState('')
  const [status, setStatus] = useState('idle')

  const handleTransmit = async () => {
    if (!name.trim() || !message.trim()) return
    setStatus('sending')

    // Mailto fallback — no API key needed.
    // Replace with your preferred form endpoint (Formspree, EmailJS, etc.)
    try {
      const subject = encodeURIComponent(`Signal from ${name}`)
      const body = encodeURIComponent(message)
      window.location.href = `mailto:contact@sashiraj.com.np?subject=${subject}&body=${body}`
      setTimeout(() => setStatus('sent'), 800)
    } catch {
      setStatus('error')
    }
  }

  const btnLabel = STATUS[status]

  return (
    <section className="py-32 px-6 lg:px-20">
      <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-20 items-center">
        {/* Left */}
        <div>
          <h2 className="font-serif text-7xl lg:text-8xl italic mb-8 reveal">
            Establish <br />Uplink.
          </h2>
          <div className="space-y-4 opacity-40">
            <p className="text-[9px] uppercase tracking-[0.5em]">
              PRIMARY NODE: {META.location.toUpperCase()}
            </p>
            <p className="text-[9px] uppercase tracking-[0.5em]">
              SYSTEM ACCESS: {META.phone}
            </p>
          </div>
        </div>

        {/* Form card */}
        <div className="p-1 t-card reveal shadow-2xl">
          <div className="bg-[var(--surface)] p-12 space-y-8">
            {/* Name */}
            <div className="space-y-1">
              <label className="text-[8px] uppercase tracking-widest text-brand-gold font-bold block">
                Signal Identity
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="NAME / ENTITY"
                className="w-full bg-transparent border-b border-main py-3 outline-none text-[13px] placeholder:text-dim/50 focus:border-brand-gold transition-colors"
              />
            </div>

            {/* Message */}
            <div className="space-y-1">
              <label className="text-[8px] uppercase tracking-widest text-brand-gold font-bold block">
                Brief
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="OBJECTIVES"
                rows={4}
                className="w-full bg-transparent border-b border-main py-3 outline-none resize-none text-[13px] placeholder:text-dim/50 focus:border-brand-gold transition-colors"
              />
            </div>

            {/* Submit */}
            <button
              onClick={handleTransmit}
              disabled={status === 'sending' || status === 'sent'}
              className="w-full bg-brand-gold text-black py-5 text-[11px] uppercase tracking-[0.5em] font-bold hover:opacity-90 transition-all disabled:opacity-60"
            >
              {btnLabel}
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
