// src/components/shared/Modal.jsx
import { useEffect } from 'react'

const TABS = ['01 Mission', '02 Specs', '03 Status']
const KEYS = ['info', 'specs', 'status']

export default function Modal({ modal, onClose, onSetCarousel }) {
  // Close on Escape
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [onClose])

  if (!modal) return null
  const { data, carouselIndex } = modal

  return (
    <div
      className={`modal-overlay flex items-center justify-center p-4 md:p-8 ${modal ? 'active' : ''}`}
      onClick={onClose}
    >
      <div
        className="bg-[var(--surface)] border border-main w-full max-w-5xl p-8 lg:p-20 relative overflow-y-auto max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-8 right-8 opacity-40 hover:opacity-100 text-2xl transition-opacity"
          aria-label="Close modal"
        >
          ✕
        </button>

        <div className="flex flex-col lg:flex-row gap-16 items-start">
          {/* Text side */}
          <div className="lg:w-3/5 space-y-10">
            <div>
              <span className="text-[10px] text-brand-gold uppercase tracking-[0.5em] font-bold block mb-4">
                {data.tag}
              </span>
              <h2 className="font-serif text-6xl italic leading-tight">{data.title}</h2>
            </div>

            {/* Carousel tabs */}
            <div className="flex gap-6 border-b border-main pb-3">
              {TABS.map((label, i) => (
                <button
                  key={label}
                  onClick={() => onSetCarousel(i)}
                  className={`text-[10px] uppercase tracking-widest transition-all ${
                    carouselIndex === i
                      ? 'opacity-100 font-bold border-b border-brand-gold'
                      : 'opacity-40'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <p className="text-dim text-lg leading-relaxed min-h-[160px] font-light">
              {data[KEYS[carouselIndex]]}
            </p>
          </div>

          {/* Visual side */}
          <div className="lg:w-2/5 w-full aspect-square bg-black/5 dark:bg-white/5 border border-main flex items-center justify-center text-brand-gold/10 font-serif italic text-[12rem] select-none">
            {data.title[0]}
          </div>
        </div>
      </div>
    </div>
  )
}
