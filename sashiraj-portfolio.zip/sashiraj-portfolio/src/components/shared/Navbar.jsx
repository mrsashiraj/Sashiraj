// src/components/shared/Navbar.jsx
import { useKathmandu } from '../../hooks/useClock'
import { META } from '../../data/portfolioData'

export default function Navbar({ theme, onToggleTheme }) {
  const time = useKathmandu()

  return (
    <nav className="fixed top-0 w-full z-[100] border-b border-main px-6 py-4 flex justify-between items-center">
      {/* Brand */}
      <div className="flex items-center gap-3">
        <span className="font-serif italic text-xl tracking-tight">{META.name.split(' ')[0][0]}. {META.name.split(' ')[1]}</span>
        <div className="h-3 w-[1px] bg-brand-gold/30" />
        <span className="text-[7px] uppercase tracking-[0.4em] text-brand-gold pt-1">{META.tagline}</span>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-6">
        <span className="text-[9px] font-mono opacity-40 hidden md:block uppercase tracking-widest">
          {time}
        </span>
        <div className="flex items-center gap-3">
          <span className="text-[8px] opacity-40 uppercase tracking-tighter">Theme</span>
          <button
            className="theme-switch"
            onClick={onToggleTheme}
            aria-label="Toggle theme"
          >
            <div className="theme-switch-dot" />
          </button>
        </div>
      </div>
    </nav>
  )
}
