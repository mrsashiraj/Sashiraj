// src/components/shared/CardGrid.jsx
export default function CardGrid({ items, onOpen, category }) {
  return (
    <>
      {items.map((item) => (
        <div
          key={item.id}
          className="t-card p-8 reveal cursor-pointer group hover:border-brand-gold"
          onClick={() => onOpen(item)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && onOpen(item)}
          aria-label={`View ${item.title} details`}
        >
          <span className="text-[9px] text-brand-gold uppercase block mb-4 font-bold tracking-widest">
            {item.tag}
          </span>
          <h3 className="font-serif text-2xl mb-4 group-hover:italic transition-all">
            {item.title}
          </h3>
          <p className="text-dim line-clamp-2 text-[13px] leading-relaxed">{item.info}</p>
        </div>
      ))}
    </>
  )
}
