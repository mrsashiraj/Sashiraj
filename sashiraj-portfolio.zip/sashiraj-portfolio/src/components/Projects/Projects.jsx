// src/components/Projects/Projects.jsx
import { PROJECTS } from '../../data/portfolioData'
import CardGrid from '../shared/CardGrid'

export default function Projects({ onOpen }) {
  return (
    <section className="py-20 px-6 lg:px-20">
      <h2 className="font-serif text-5xl italic mb-12 reveal">Project Intelligence</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <CardGrid items={PROJECTS} onOpen={onOpen} category="projects" />
      </div>
    </section>
  )
}
