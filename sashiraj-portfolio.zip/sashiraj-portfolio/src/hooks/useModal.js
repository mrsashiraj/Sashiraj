// src/hooks/useModal.js
import { useState, useCallback } from 'react'

export function useModal() {
  const [modal, setModal] = useState(null) // { data, carouselIndex }

  const openModal = useCallback((data) => {
    setModal({ data, carouselIndex: 0 })
    document.body.style.overflow = 'hidden'
  }, [])

  const closeModal = useCallback(() => {
    setModal(null)
    document.body.style.overflow = 'auto'
  }, [])

  const setCarousel = useCallback((i) => {
    setModal(prev => prev ? { ...prev, carouselIndex: i } : prev)
  }, [])

  return { modal, openModal, closeModal, setCarousel }
}
