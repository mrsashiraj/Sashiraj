// src/hooks/useClock.js
import { useState, useEffect } from 'react'

export function useKathmandu() {
  const [time, setTime] = useState('')

  useEffect(() => {
    const update = () => {
      const t = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Kathmandu',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }).format(new Date())
      setTime(`${t} KTM`)
    }
    update()
    const interval = setInterval(update, 1000)
    return () => clearInterval(interval)
  }, [])

  return time
}
