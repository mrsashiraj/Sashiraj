// src/App.jsx
import { useTheme } from './hooks/useTheme'
import { useModal } from './hooks/useModal'
import { useReveal } from './hooks/useReveal'

import Navbar        from './components/shared/Navbar'
import WhatsAppFloat from './components/shared/WhatsAppFloat'
import Modal         from './components/shared/Modal'
import Hero          from './components/Hero/Hero'
import Skills        from './components/Skills/Skills'
import Projects      from './components/Projects/Projects'
import Ventures      from './components/Ventures/Ventures'
import Timeline      from './components/Timeline/Timeline'
import Academics     from './components/Academics/Academics'
import Research      from './components/Research/Research'
import Contact       from './components/Contact/Contact'

export default function App() {
  const { theme, toggle } = useTheme()
  const { modal, openModal, closeModal, setCarousel } = useModal()
  useReveal()

  return (
    <>
      <WhatsAppFloat />

      <Navbar theme={theme} onToggleTheme={toggle} />

      <main>
        <Hero />
        <Skills />
        <Projects  onOpen={openModal} />
        <Ventures  onOpen={openModal} />
        <Timeline />
        <Academics />
        <Research  onOpen={openModal} />
        <Contact />
      </main>

      <Modal modal={modal} onClose={closeModal} onSetCarousel={setCarousel} />
    </>
  )
}
